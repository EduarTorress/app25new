<?php

namespace Clases;

class cliente
{
    public $nombre;
    public $ruc;
    public $direccion;
    public $ciudad;
    public $celular;
    public $fono;
    public $email;
    public $referencia;
    public $tipocliente;
    public $vendedor;
    public function CrearCliente()
    {
    }
}
