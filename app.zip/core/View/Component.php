<?php
namespace Core\View;

abstract class Component{
    abstract public function render();
}
?>