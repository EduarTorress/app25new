<?php
namespace App\View\Components;

use Core\View\Component;

class FechaComponent extends Component
{
    function render()
    {
        return view('components/fecha');
    }
}
