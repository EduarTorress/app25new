<?php

namespace App\View\Components;

use Core\View\Component;

class Modaload extends Component
{
    function render()
    {
        return view('components/modaload');
    }
}
