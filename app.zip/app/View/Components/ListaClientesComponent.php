<?php

namespace App\View\Components;

use Core\View\Component;

class ListaClientesComponent extends Component
{
    public function render()
    {
        return view('components/modalclientes');
    }
}
