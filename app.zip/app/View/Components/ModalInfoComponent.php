<?php

namespace App\View\Components;

use Core\View\Component;

class ModalInfoComponent extends Component
{   
    function render()
    {
        return view('components/modalinfo');
    }
}
