<?php

namespace App\View\Components;

use Core\View\Component;

class FechavtoComponent extends Component
{
    function render()
    {
        return view('components/fechavto');
    }
}
