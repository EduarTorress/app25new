<?php

namespace App\Models;

use Core\Routing\Modelo;
use PDOException;
use PDO;

class Vehiculo extends Modelo
{
}
