<ul>
    <?php foreach ($listado as $item) : ?>
        <li><?php echo $item['descri'] ?></li>
    <?php endforeach; ?>
</ul>