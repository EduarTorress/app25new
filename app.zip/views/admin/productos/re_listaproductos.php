<?php
$lista = new \App\View\Components\Listaproductos();
echo $lista->render();
?>