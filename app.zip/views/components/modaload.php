<div id="loading" class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title title-center">Procesando Solicitud</h5>
            </div>
            <div class="modal-body">
                <div id="contenedor">
                    <div class="loader" id="loader">Loading...</div>
                </div>
            </div>
        </div>
    </div>
</div>