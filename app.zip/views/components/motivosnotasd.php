<div id="cmbMotivoNotaD" class="">
    <label class="form-control form-control-sm" for="">Motivo:</label>
    <select class="form-select-sm form-control form-control-sm" id="cmbMotivoD" name="cmbMotivoD">
        <option selected value="01">01 - Intereses por mora</option>
        <option value="02">02 - Aumento en el valor</option>
        <option value="03">03 - Penalidades/ otros conceptos</option>
        <option value="11">11 - Ajustes de operaciones de exportación</option>
        <option value="12">12 - Ajustes afectos al IVAP</option>
    </select>
</div>