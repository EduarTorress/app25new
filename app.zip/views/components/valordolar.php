<div class="input-group">&nbsp;&nbsp;&nbsp;
    <label class="col-sm-0 col-form-label col-form-label-sm">Dolar : </label>
    <input type="text" id="txtdolar" class="form-control form-control-sm" value="<?php echo $dolar ?>" style="width: 26%;" placeholder="0.00">
</div>