<div id="cmbMotivoNotaC" class="">
    <label class="form-control form-control-sm" for="">Motivo:</label>
    <select class="form-select-sm form-control form-control-sm" id="cmbMotivo" name="cmbMotivo">
        <option selected value="01">01 - Anulación de la operación</option>
        <option value="02">02 - Anulación por error RUC</option>
        <option value="03">03 - Corrección por error en la descripción</option>
        <option value="04">04 - Descuento global</option>
        <option value="05">05 - Descuento por item</option>
        <option value="06">06 - Devolución total</option>
        <option value="07">07 - Devolución por item</option>
        <option value="08">08 - Bonificación</option>
        <option value="09">09 - Disminución en el valor</option>
        <option value="10">10 - Otros Conceptos</option>
        <option value="11">11 - Ajustes de operaciones de exportación</option>
        <option value="12">12 - Ajustes afectos al IVAP</option>
        <option value="13">13 - Ajustes - montos y/o fechas de pago</option>      
    </select>
</div>